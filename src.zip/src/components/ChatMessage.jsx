import robotProfileImage from "../assets/robot.png";
import userProfileImage from "../assets/user.png";
import './ChatMessage.css'
// ------------------
export default function ChatMessage({ message, sender }) {
  return (
    <div className={sender === "robot" ? "robot-message" : "user-message"}>
      {sender === "robot" && <img src={robotProfileImage} width="55" />}
      <p>{message}</p>
      {sender === "user" && <img src={userProfileImage} width="55" />}
    </div>
  );
}
